<?php
/**
 * Silence is gold
 */